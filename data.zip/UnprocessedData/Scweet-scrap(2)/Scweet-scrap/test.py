time_value_list = []
if time_value_list:
    print("yes")
else:
    print("No")