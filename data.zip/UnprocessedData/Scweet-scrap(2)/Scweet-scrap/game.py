def find_max_consecutive(goods_sequence, n):
    max_consecutive = 0
    start = 0
    max_count = 0
    count_map = {}

    for end in range(len(goods_sequence)):
        current = goods_sequence[end]
        count_map[current] = count_map.get(current, 0) + 1
        max_count = max(max_count, count_map[current])

        if (end - start + 1) - max_count > n:
            start_num = goods_sequence[start]
            count_map[start_num] -= 1
            if count_map[start_num] == 0:
                del count_map[start_num]
            start += 1

        max_consecutive = max(max_consecutive, end - start + 1)

    return max_consecutive


n = 2
goods_sequence = [2, 4, 3, 3, 4, 4, 4, 5]
max_consecutive = find_max_consecutive(goods_sequence, n)
print("可能的最长连续相同编号货物的数量是:", max_consecutive)