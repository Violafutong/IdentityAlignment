from selenium.webdriver.common.by import By

from . import utils
from time import sleep
import random
import json
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


def get_proxy():
    PROXY_POOL = [
        "jp02.clashcloud.tech", "jp08.clashcloud.tech", "ca05.clashcloud.tech"
    ]
    # 使用您所选的动态代理池，根据其文档和示例获取代理，并确保代理地址中包含协议和混淆参数
    proxy = "http://us10.clashcloud.tech"
    return proxy


def get_user_information(users, headless=True):
    """ get user information if the "from_account" argument is specified """
    proxy = get_proxy()
    driver = utils.init_driver(headless=headless)
    env = ".env"

    utils.log_in(driver, env, wait=2)
    users_posts_info = {}
    fail_Num = 0

    for i, user in enumerate(users):

        log_user_page(user,driver)
        sleep(random.uniform(21, 25))

        time_value_list = []
        if user is not None:

            try:
                print(user)
                time_elements = driver.find_elements(By.XPATH,
                                                     '//article//div[1]//div[1]//div[2]//div[2]//div[1]//div[1]//div[1]//div[1]//div[1]//div[2]//div[1]//div[3]//a//time')

                # 遍历所有找到的 <time> 元素，并获取其 datetime 属性值
                for time_element in time_elements:
                    datetime_value = time_element.get_attribute("datetime")

                    time_value_list.append(datetime_value)
                    print(datetime_value)

            except Exception as e:
                print(e)
                return
            print("--------------- " + user + " Posts Time : ---------------")
            if i == len(users) - 1:
                driver.close()
        else:
            print("You must specify the user")
            continue
        if time_value_list:
            users_posts_info[user] = time_value_list
        else:
            fail_Num += 1
    return users_posts_info, fail_Num


def log_user_page(user, driver, headless=True):
    sleep(random.uniform(1, 2))
    sleep(random.uniform(1, 2))
    driver.get('https://twitter.com/' + user)


PROXY_POOL = ["jp01.clashcloud.tech", "jp02.clashcloud.tech", "jp03.clashcloud.tech", "jp04.clashcloud.tech",
              "jp05.clashcloud.tech", "jp06.clashcloud.tech", "jp07.clashcloud.tech", "jp08.clashcloud.tech",
              "jp09.clashcloud.tech",
              "ca01.clashcloud.tech", "ca02.clashcloud.tech", "ca03.clashcloud.tech", "ca04.clashcloud.tech",
              "ca05.clashcloud.tech"
              "kr01.clashcloud.tech", "kr02.clashcloud.tech",
              "us01.clashcloud.tech", "us02.clashcloud.tech",
              "au01.clashcloud.tech"
              ]


def get_users_followers(users, env, verbose=1, headless=True, wait=2, limit=float('inf'), file_path=None):
    followers = utils.get_users_follow(users, headless, env, "followers", verbose, wait=wait, limit=limit)

    if file_path == None:
        file_path = 'outputs/' + str(users[0]) + '_' + str(users[-1]) + '_' + 'followers.json'
    else:
        file_path = file_path + str(users[0]) + '_' + str(users[-1]) + '_' + 'followers.json'
    with open(file_path, 'w') as f:
        json.dump(followers, f)
        print(f"file saved in {file_path}")
    return followers


def get_users_following(users, env, verbose=1, headless=True, wait=2, limit=float('inf'), file_path=None):
    following = utils.get_users_follow(users, headless, env, "following", verbose, wait=wait, limit=limit)

    if file_path == None:
        file_path = 'outputs/' + str(users[0]) + '_' + str(users[-1]) + '_' + 'following.json'
    else:
        file_path = file_path + str(users[0]) + '_' + str(users[-1]) + '_' + 'following.json'
    with open(file_path, 'w') as f:
        json.dump(following, f)
        print(f"file saved in {file_path}")
    return following


def hasNumbers(inputString):
    return any(char.isdigit() for char in inputString)
