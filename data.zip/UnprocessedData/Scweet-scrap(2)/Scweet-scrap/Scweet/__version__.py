VERSION = (1, 8)

__version__ = '.'.join(map(str, VERSION))