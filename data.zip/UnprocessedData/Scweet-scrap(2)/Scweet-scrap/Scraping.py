import random
from time import sleep

from Scweet.scweet import scrape
from Scweet.user import get_user_information, get_users_following, get_users_followers

# scrape top tweets with the words 'covid','covid19' and without replies. the process is slower as the interval is
# smaller (choose an interval that can divide the period of time betwee, start and max date) scrape english top
# tweets geolocated less than 200 km from Alicante (Spain) Lat=38.3452, Long=-0.481006.
# data = scrape(words=['bitcoin', 'ethereum'], since="2021-10-01", until="2021-10-05", from_account=None, interval=1,
#               headless=False, display_type="Top", save_images=False, lang="en",
#               resume=False, filter_replies=False, proximity=False, geocode="38.3452,-0.481006,200km")
#
# # scrape top tweets of with the hashtag #covid19, in proximity and without replies. the process is slower as the
# # interval is smaller (choose an interval that can divide the period of time betwee, start and max date)
# data = scrape(hashtag="bitcoin", since="2021-08-05", until="2021-08-08", from_account=None, interval=1,
#               headless=True, display_type="Top", save_images=False,
#               resume=False, filter_replies=True, proximity=True)

# Get the main information of a given list of users
# These users belongs to my following. 

import json
import threading
import requests
t = 4


def scrap(current_index, batch_size):
    final_index = current_index + t * batch_size
    with open('username.json', 'r') as file:
        data = json.load(file)
    while current_index < final_index:
        end_index = min(current_index + batch_size, len(data))
        users_batch = data[current_index:end_index]
        print("current_index:----------", current_index)
        users_posts_info, fail_Num = get_user_information(users_batch, headless=True)

        print(users_posts_info)

        print("Users not exist count: ", fail_Num)
        with open('UserPosts/userPostsInformation{}.json'.format(current_index), 'w') as f:
            f.seek(0, 2)  # 将文件指针移动到文件末尾

            json.dump(users_posts_info, f)
        current_index += batch_size * t
        final_index = current_index + batch_size * t

        print("current_index-----", current_index)
        print("final_index-----", final_index)


def multiple_threads(current_indexes, batch_size):
    # 创建一个线程列表
    threads = []
    # 创建和启动线程
    for current_index in current_indexes:
        sleep(random.randint(1, 6))
        print("++==============================={}".format(current_index))

        thread = threading.Thread(target=scrap, args=(current_index, batch_size))
        thread.start()
        threads.append(thread)
    # 等待所有线程完成
    for thread in threads:
        thread.join()


print("++================current_indexes1===============")
if __name__ == "__main__":
    print('This is main of module "world.py"')

    current_indexes1 = [11101]  # 用户名称爬取起点，这里相当于两个线程一个从1421另一个
#    current_indexes1 = [11101, 11121]  # 用户名称爬取起点，这里相当于两个线程一个从1421另一个
    batch_size = 20
    multiple_threads(current_indexes1, batch_size)

    print(__name__)
