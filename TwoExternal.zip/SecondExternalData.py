import base64
import hashlib
import json
import random
import string
from datetime import timedelta

import pandas as pd


def secondPostsgengrate(file, exfile):
    df = pd.read_csv(file)
    df["User"] = "db" + df["User"]
    df["Time"] = pd.to_datetime(df["Time"]) + timedelta(days=1) + timedelta(hours=1)
    df["Label"] = "Douban"
    # 输出修改后的数据
    df.to_csv(exfile)
    print(df.head())


def generateUserNamelist(file):
    df = pd.read_csv(file)
    user_list = df["User"].unique().tolist()
    first_10 = user_list[:50]
    last_10 = user_list[50:]
    user_mapping = {key: value for key, value in zip(last_10, first_10)}
    with open("dataTwo/usernames_mapping.csv", 'w') as f:
        json.dump(user_mapping,f)
    print(user_mapping)
    return user_mapping


def TrackingDataGenerate():
    df_twitter = pd.read_csv("dataTwo/dataTwitterPosts.csv")
    df_sina = pd.read_csv("dataTwo/dataSinaPosts.csv")
    # 取出各自前5000个用户
    twitter_users = set(df_twitter['User'][:])
    sina_users = set(df_sina['User'][:])
    print(len(twitter_users))
    print(len(sina_users))
    # 创建一个空的结果DataFrame
    df_result = pd.DataFrame(columns=['Time', 'Event', 'User', 'Label', 'Domain', 'Tracking ID'])

    twitter_users = list(twitter_users)[:4626]
    sina_users = list(sina_users)[:4626]
    print(len(twitter_users))
    print(len(sina_users))
    # 遍历前5000个用户

    unique_ids = []
    usernames = {}
    for i in range(4626):
        twitter_user = twitter_users[i]
        sina_user = sina_users[i]

        # 生成长度为64的唯一标识符
        unique_id = generate_unique_id(twitter_user)
        unique_ids.append(unique_id)
        usernames[unique_id] = {twitter_user, sina_user}

        # 将Twitter用户数据和相关信息添加到结果DataFrame中
        twitter_data = df_twitter[df_twitter['User'] == twitter_user]
        for _, row in twitter_data.iterrows():
            df_result = df_result._append(
                {'Time': row['Time'], 'User': row['User'], 'Event': 'Posts', 'Label': "both", 'Domain': row['Label'],
                 'Tracking ID': unique_id}, ignore_index=True)

        # 将Sina用户数据和相关信息添加到结果DataFrame中
        sina_data = df_sina[df_sina['User'] == sina_user]
        for _, row in sina_data.iterrows():
            df_result = df_result._append(
                {'Time': row['Time'], 'User': row['User'], 'Event': 'Posts', 'Label': 'both', 'Domain': row['Label'],
                 'Tracking ID': unique_id},
                ignore_index=True)
    # 打印结果
    print(df_result)

    df_result.to_csv("dataTwo/trackingData.csv")
    with open('dataTwo/usernames1.csv', 'w') as f:
        [f.write('{0},{1}\n'.format(key, value)) for key, value in usernames.items()]


def changeTrackingData(user_pairs):
    df = pd.read_csv('dataTwo/trackingData.csv')
    trackingID_mapping = {}
    for user, userfirst in user_pairs.items():
        twitter_data2 = df[df['User'] == user]['Tracking ID'].values[0]
        twitter_data1 = df[df['User'] == userfirst]['Tracking ID'].values[0]
        trackingID_mapping[twitter_data2] = twitter_data1

    df['Tracking ID'] = df['Tracking ID'].replace(trackingID_mapping)
    print(df.head())
    # df.to_csv('dataTwo/trackingDataChanged.csv')


def generate_unique_id(string):
    # 使用SHA-256哈希函数计算摘要
    hash_object = hashlib.sha256(string.encode())
    hash_digest = hash_object.digest()
    # 使用Base64编码将摘要转换为字符串
    unique_id = base64.b64encode(hash_digest).decode()
    # 截取64个字符长度的唯一性标识符
    unique_id = unique_id[:64]
    return unique_id


if __name__ == '__main__':
    user_pairs = generateUserNamelist('D:\BUPT\IdentityAlignment\data\dataTwitterPosts.csv')

    # TrackingDataGenerate()
    changeTrackingData(user_pairs)

    # secondPostsgengrate('D:\BUPT\IdentityAlignment\dataTwo\dataTwitterPosts.csv',"dataTwo/dataFacebookPosts.csv")
